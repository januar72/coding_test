<section class="content-header">
	<h1>
		<small>Detail Pesan</small>
	</h1>
	<ol class="breadcrumb">
		<li><a href=""><i class="fa fa-dashboard"> Dashboard</i></a></li>
		<li><a href="">Admin</a></li>
		<li class="active">Detail Pesan</li>
	</ol>
</section>
<sectionn class="content">
	<div class="row">
		<div class="col-lg-12">
			<div class="box box-default">
				<div class="box-header with-border">
					<h3 class="box-title">Tabel Detail Pesan</h3>
				</div>
				<div class="box-body" style="overflow: auto;">
					<table class="table table-bordered table-striped" id="example1">
						<thead>
							<tr>
								<th>No</th>
								<th>Tgl Awal</th>
								<th>Tgl Akhir</th>
								<th>No Wa</th>
								<th>Aksi</th>
							</tr>
						</thead>
						<tbody>
							<?php include 'koneksi.php';
							$no =1;
							$tampil=mysqli_query($conn, "SELECT * FROM tb_pesan ORDER BY id_pesan");
							while ($data=mysqli_fetch_array($tampil, MYSQLI_ASSOC)) {?>
								<tr>
									<td><?php echo $no++; ?></td>
									<td><?php echo $data['tgl_awal']; ?></td>
									<td><?php echo $data['tgl_akhir']; ?></td>
									<td><?php echo $data['no_wa']; ?></td>
									<td>
										<a href="hapus_pesan.php?id=<?php echo $data['id_pesan']; ?>" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i></a>
									</td>
								</tr>
							<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</sectionn>