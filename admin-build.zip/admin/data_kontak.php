<section class="content-header">
	<h1>
		<small>Data Kontak</small>
	</h1>
	<ol class="breadcrumb">
		<li><a href=""><i class="fa fa-dashboard">Dashboard</i></a></li>
		<li><i class="">Admin</i></li>
		<li class="active">Data Kontak</li>
	</ol>
</section>
<section class="content">
	<div class="row">
		<div class="col-lg-3">
			<div class="box box-default">
				<div class="box-header with-border">
					<h3 class="box-title">Input Data Kontak</h3>
				</div>
				<form role="form" action="proses_kontak.php" method="post" enctype="multipart/form-data">
					<div class="box-body">
						<?php 
						if (isset($_GET['notif'])) {
							if ($_GET['notif'] == 'gagal') {
								echo "
			                <div class='alert alert-danger alert-dismissible' style='text-align:justify; font-size:10px;'>
			                <a href='dashboard_admin.php?p=data_kontak' class='close' style='text-decoration:none'>&times;</a>
			                <h4 style='font-size:12px;'><i class='icon fa fa-ban'></i> Gagal!</h4>
			                  Kontak yang anda masukkan sudah terdaftar....
			                </div>";
							}
						}else{
							echo "";
						}

						 ?>
						<div class="form-group">
							<label>Alamat</label>
							<input type="text" name="alamat" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Email</label>
							<input type="email" name="email" class="form-control" required>
						</div>
						<div class="form-group">
							<label>No Hp</label>
							<input type="text" name="no_hp" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Instagram</label>
							<input type="text" name="ig" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Youtube</label>
							<input type="text" name="yt" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Tik Tok</label>
							<input type="text" name="tiktok" class="form-control" required>
						</div>
						<div class="form-group">
							<label>Maps</label>
							<textarea name="maps" class="form-control" rows="10" cols="5" placeholder="https-2sid"></textarea>
						</div>
						<div class="box-footer">
							<button type="submit" name="simpan" class="btn btn-primary">Simpan</button>
						</div>
					</div>
				</form>
			</div>
		</div>
		<div class="col-lg-9">
		<div class="box box-default">
			<div class="box-header with-border">
				<h3 class="box-title">Tabel Data Kontak</h3>
			</div>
			<div class="box-body" style="overflow: auto;">
				<?php 
					if (isset($_GET['notif'])) {
						if ($_GET['notif'] =='sukses') {
							 echo "
			                <div class='alert alert-success alert-dismissible' style='text-align:justify; font-size:10px;'>
			                <a href='dashboard_admin.php?p=data_kontak' class='close' style='text-decoration:none'>&times;</a>
			                <h4 style='font-size:12px;'><i class='icon fa fa-check'></i> Sukses......</h4>
			                  Data Kontak berhasil disimpan...
			                </div>";
						}if ($_GET['notif'] == 'sukses_edit') {
							 echo "
			                <div class='alert alert-warning alert-dismissible' style='text-align:justify; font-size:10px;'>
			                <a href='dashboard_admin.php?p=data_kontak' class='close' style='text-decoration:none'>&times;</a>
			                <h4 style='font-size:12px;'><i class='icon fa fa-check'></i> Sukses......</h4>
			                  Data Kontak berhasil disimpan...
			                </div>";
						}if ($_GET['notif'] == 'sukses_hapus') {
							 echo "
			                <div class='alert alert-danger alert-dismissible' style='text-align:justify; font-size:10px;'>
			                <a href='dashboard_admin.php?p=data_kontak' class='close' style='text-decoration:none'>&times;</a>
			                <h4 style='font-size:12px;'><i class='icon fa fa-check'></i> Sukses......</h4>
			                  Data Kontak berhasil disimpan...
			                </div>";
						}
					}else{
						echo "";
					}

					 ?>
				<table id="example1" class="table table-bordered table-striped">
					<thead>
						<tr>
							<th>No</th>
							<th>Alamat</th>
							<th>Email</th>
							<th>No Hp</th>
							<th>Instagram</th>
							<th>Youtube</th>
							<th>Tik Tok</th>
							<th>Maps</th>
							<th>Aksi</th>
						</tr>
					</thead>
					<tbody>
						<?php 
						include 'koneksi.php';
						$no=1;
						$tampil=mysqli_query($conn, "SELECT * FROM tb_kontak ORDER BY id_kontak DESC");
						while ($data=mysqli_fetch_array($tampil, MYSQLI_ASSOC)) : ?>
							<tr>
								<td><?php echo $no++; ?></td>
								<td><?php echo $data['alamat']; ?></td>
								<td><?php echo $data['email']; ?></td>
								<td><?php echo $data['no_hp']; ?></td>
								<td><?php echo $data['ig']; ?></td>
								<td><?php echo $data['yt']; ?></td>
								<td><?php echo $data['tiktok']; ?></td>
								<td>
                            	<iframe src="<?php echo $data['maps']; ?>" width="200" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                            	</td>
								<td>
									<a onclick="return confirm('yakin hapus..!')" href="hapus_kontak.php?id=<?php echo $data['id_kontak']; ?>" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i></a>
								</td>
							</tr>
						<?php endwhile; ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
	</div>
</section>