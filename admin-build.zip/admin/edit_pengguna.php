<section class="content-header">
	
</section>
<section class="content" style="padding-top: 4rem;">
	<div class="row">
		<div class="col-lg-12">
			<div class="box box-default">
				<div class="box-header with-border">
					<h3 class="box-title">form edit User</h3>
				</div>
				<?php
				include './koneksi.php'; 
				$id =$_GET['id'];
				$tampil =mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM tb_user WHERE id_user ='$id'"));
				 ?>
				 <form role="form" method="post" action="proses_edituser.php?id=<?php echo $id;?>">
                  <div class="box-body">
                    <div class="row">
                      <div class="col-lg-4">
                        <div class="form-group">
                          <label>Nama</label>
                          <input type="text" class="form-control" value="<?php echo $tampil['nama'];?>" name="nama" required="required">
                        </div>
                      </div>
                      <div class="col-lg-4">
                         <div class="form-group">
                          <label>Jabatan</label>
                          <select name="jabatan" required="required" class="form-control">
                            <option value="<?php echo $tampil['jabatan']; ?>"><?php echo $tampil['jabatan']; ?></option>
                            <option value="user">user</option>
                            <option value="admin">admin</option>
                            <option value="owner">owner</option>
                          </select>
                          </div>
                        </div>
                    	<div class="col-lg-4">
                         <div class="form-group">
                          <label>Status Aktif</label>
                          <select name="status" required="required" class="form-control">
                            <option value="aktif">Aktif</option>
                            <option value="non aktif">Tidak Aktif</option>
                          </select>
                          </div>
                        </div>
                  </div>
                  <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </div>
                </form>
			</div>
		</div>
	</div>
</section>