<section class="content-header">
	<h1>
		<small>Data Mobil</small>
	</h1>
	<ol class="breadcrumb">
		<li><a href=""><i class="fa fa-dashboard">Dashboard</i></a></li>
		<li><a href="">Admin</a></li>
		<li class="active">Data Mobil</li>
	</ol>
</section>
<section class="content">
	<div class="row">
		<div class="col-lg-4">
			<div class="box box-success">
				<div class="box-header with-border">
					<h3 class="box-title">Input Mobil</h3>
				</div>
				<div class="box-body" style="overflow: auto;">
					<form method="post" action="proses_mobil.php" enctype="multipart/form-data">
						<div class="form-group">
							<label>Foto Mobil</label>
							<input type="file" name="foto" class="form-control" required>
						</div>
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label>Merek Mobil</label>
									<input type="text" name="merek" class="form-control" required>
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label>Model</label>
									<input type="text" name="model" class="form-control" required>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label>No Plat</label>
									<input type="text" name="no_plat" class="form-control" required>
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label>Tarif</label>
									<input type="text" name="tarif" class="form-control" required>
								</div>
							</div>
						</div>
						<div class="box-footer">
							<input type="submit" name="simpan" class="btn btn-primary">
						</div>
					</form>
				</div>
			</div>
		</div>
		<div class="col-lg-8">
			<div class="box box-success">
				<div class="box-header with-border">
					<h3 class="box-title">Tabel Mobil</h3>
				</div>
				<div class="box-body" style="overflow: auto;">
					<table id="example1" class="table table-bordered table-striped">
						<thead>
							<tr>
								<th>No</th>
								<th>Gambar Mobil <br>
									<i style="font-size: 8px;"></i></th>
								<th>Merek</th>
								<th>Model</th>
								<th>No Plat</th>
								<th>Tarif</th>
								<th>Aksi</th>
							</tr>
						</thead>
						<tbody>
							<?php include 'koneksi.php';
							$no=1;
							$tam=mysqli_query($conn, "SELECT * FROM tb_mobil");
							while ($data=mysqli_fetch_array($tam, MYSQLI_ASSOC)) { ?>
								<tr>
									<td><?php echo $no++; ?></td>
									<td>
					 					<a href="dashboard_admin.php?p=foto&foto=<?php echo $data['foto']; ?>" class="btn btn-danger" style="padding: 0;">
					 					 <img src="./berkas/<?php echo $data['foto'];?>" style="width: 50px; height: 50px;">
					 					</a>
					 				</td>
									<td><?php echo $data['merek']; ?></td>
									<td><?php echo $data['model']; ?></td>
									<td><?php echo $data['no_plat']; ?></td>
									<td><?php echo $data['tarif']; ?></td>
									<td>
										<a href="hapus_mobil.php?id=<?php echo $data['id_mobil']; ?>" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i></a>
									</td>
								</tr>
							<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</section>