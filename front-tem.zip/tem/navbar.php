 <!-- awal navbar -->
  <nav class="navbar navbar-expand-lg navbar-dark fixed-top shadow-sm " style="background-color:#94bbe9;">
    <div class="container">
     <a class="navbar-brand" href="index.php">
      <h1>JM TRANSMEDIC</h1>
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
        
        <li class="nav-item dropdown">
          <a class="nav-link active dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Pages
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="mobil.php">Halaman Mobil</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a href="login.php" class="dropdown-item"><i class="fa-solid fa-right-to-bracket"></i> Login</a></li>
          </ul>
        </li> 

        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="contact.php">Contact</a>
        </li>

      </ul>
      <form class="d-flex" action="" method="get">
        <input class="form-control me-2" type="search" placeholder="cek mobil.." name="cari" autocomplete="off" aria-label="Search">
        <button class="btn btn-outline-success me-2" name="cari" type="submit">Search</button>
        <a href="" class="btn btn-outline-danger"><i class="bi bi-cart"></i></a>
      </form>
    </div>
    </div>
  </nav>
  <!-- akhir navbar -->

