
 <?php
 session_start(); 
include 'koneksi.php';
if (isset($_POST['masuk'])) {
	$username =htmlspecialchars($_POST['username']);
	$password =htmlspecialchars($_POST['password']);

$simpan =mysqli_query($conn, " SELECT * FROM tb_user WHERE username='$username' AND password='$password' AND status='aktif' ORDER BY id_user");
// var_dump($simpan);
// die();
$cek=mysqli_num_rows($simpan);
$data=mysqli_fetch_array($simpan);
if ($cek > 0) {
	if ($data['jabatan'] == 'admin') {
		$_SESSION['masuk'] =$user;
		header("Location:dashboard_admin.php");
	}elseif ($data['jabatan'] == 'owner') {
		$_SESSION['owner'] =$user;
		header("Location:dashboard_owner.php");
	}
}elseif ($cek == 0) {
	header("Location:login.php?notif=gagal");
}

}

  ?>