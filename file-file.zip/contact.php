  <?php include 'tem/header.php'; ?>
  <?php include 'tem/navbar.php'; ?>
  <!-- kontak -->
   <section class="contact" id="contact">
     <div class="container">
       <div class="row text-center mb-3 mt-5">
         <div class="col mt-5 mb-3">
           <h2>Kontak <span>Kami</span></h2>
         </div>
       </div>
       <div class="row justify-content-center">
         <div class="col-md-8">
           <form method="post" action="proses_pesan.php">

            <div class="mb-3">
              <label for="tgl_awal" class="form-label">Tanggal Awal</label>
              <input type="date" name="tgl_awal" class="form-control" required placeholder="tgl awal.." id="tgl_awal" >
            </div>

            <div class="mb-3">
              <label for="tgl_akhir" class="form-label">Tanggal Akhir</label>
              <input type="date" name="tgl_akhir" class="form-control" required placeholder="tgl akhir.." id="tgl_akhir" >
            </div>

            <div class="mb-3">
              <label for="no_hp" class="form-label">No Wa</label>
              <input type="number" name="no_wa" placeholder="your number" required class="form-control" id="no_wa">
            </div>

            <button type="submit" name="simpan" onclick="confirm('data segera terikirm mohon cek pesan watshapMu...!');" class="btn btn-primary">Submit</button>
          </form>
         </div>
       </div>
     </div>
   </section>
   <?php include 'tem/footer.php'; ?>