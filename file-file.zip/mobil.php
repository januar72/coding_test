<?php include 'tem/header.php'; ?>
<?php include 'tem/navbar.php'; ?>
 <!-- awal prodak -->
 <section class="prodak mt-10">
   <div class="container">
     <div class="row mb-3">
       <div class="col-mt-5 text-center">
         <h2>Product Mobil</h2>
       </div>
     </div>
     <div class="row justify-content-evenly">
      <?php include 'koneksi.php';
      $tampil=mysqli_query($conn, "SELECT * FROM tb_mobil ORDER BY id_mobil DESC");
      if (isset($_GET['cari'])) {
        $tampil=mysqli_query($conn, "SELECT * FROM tb_mobil WHERE merek   LIKE '%".$_GET['cari']."%'");
      }
      while ($data=mysqli_fetch_array($tampil, MYSQLI_ASSOC)) { ?>
       <div class="col-md-4 mb-3">
         <div class="card rounded-3" style="background-image: url(berkas/je.webp);">
           <img src="./berkas/<?php echo $data['foto']; ?>" class="card-img-top rounded-3" alt="maaf gambar kosong">
           <div class="card-body">
             <p class="card-text text-center"><?php echo $data['merek']; ?></p>
             <p class="text-center"><?php echo $data['tarif']; ?></p>
             <p class="text-center"><?php echo $data['model']; ?></p>
           </div>
         </div>
       </div>
       <?php } ?>
     </div>
   </div>
 </section>
 <!-- akhir prodak -->
<?php include 'tem/footer.php'; ?>
