<?php 
include 'koneksi.php';
if (isset($_POST['simpan'])) {
	$direktori ="berkas/";
	$file_name =$_FILES['foto']['name'];
	move_uploaded_file($_FILES['foto']['tmp_name'],$direktori.$file_name);

	$merek =$_POST['merek'];
	$model =$_POST['model'];
	$no_plat =$_POST['no_plat'];
	$tarif  =$_POST['tarif'];

$simpan =mysqli_query($conn, "INSERT INTO `tb_mobil` (`id_mobil`,`foto`, `merek`,`model`,`no_plat`,`tarif`) VALUES (null, '$file_name','$merek','$model','$no_plat','$tarif')");
header("location:dashboard_admin.php?p=data_mobil");
}

 ?>