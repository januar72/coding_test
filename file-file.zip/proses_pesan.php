<?php 
include 'koneksi.php';
if (isset($_POST['simpan'])) {
$tgl_awal =$_POST['tgl_awal'];
$tgl_akhir =$_POST['tgl_akhir'];
$no_wa =$_POST['no_wa'];

$simpan =mysqli_query($conn, "INSERT INTO `tb_pesan` (`id_pesan`,`tgl_awal`,`tgl_akhir`,`no_wa`) VALUES (null, '$tgl_awal','$tgl_akhir','$no_wa')");

header("Location:contact.php");
}
 ?>