<?php
include "koneksi.php";
$id = $_GET['id'];
$nama = htmlspecialchars($_POST['nama']);
$jabatan= htmlspecialchars($_POST['jabatan']);
$status = htmlspecialchars($_POST['status']);

$query_simpan=mysqli_query($conn, "UPDATE tb_user SET nama='$nama', jabatan='$jabatan', status='$status' WHERE id_user='$id'");

header("location:dashboard_admin.php?p=index_admin&notif=sukses_edit");
?>