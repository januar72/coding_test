<?php
include "koneksi.php";
$nama = htmlspecialchars($_POST['nama']);
$jabatan= htmlspecialchars($_POST['jabatan']);
$username = htmlspecialchars($_POST['username']);
$password = htmlspecialchars($_POST['password']);

$cek = mysqli_query($conn, "SELECT * FROM tb_user WHERE username='$username'");
$result = mysqli_num_rows($cek);
$data = mysqli_fetch_array($cek);
if ($result > 0) {
    header("location:dashboard_admin.php?p=index_admin&notif=gagal");
}elseif ($result == 0) {
    $query_simpan=mysqli_query($conn, "INSERT INTO `tb_user` (`id_user`, `nama`,`username`, `password`, `jabatan`, `status`) VALUES ('', '$nama', '$username', '$password', '$jabatan', 'Aktif')");
    header("location:dashboard_admin.php?p=index_admin&notif=sukses");
}
?>