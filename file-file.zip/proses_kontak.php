<?php 
include 'koneksi.php';
if (isset($_POST['simpan'])) {
$alamat =htmlspecialchars($_POST['alamat']);
$email =htmlspecialchars($_POST['email']);
$no_hp =htmlspecialchars($_POST['no_hp']);
$ig =htmlspecialchars($_POST['ig']);
$yt =htmlspecialchars($_POST['yt']);
$tiktok =htmlspecialchars($_POST['tiktok']);
$maps =htmlspecialchars($_POST['maps']);

$simpan =mysqli_query($conn, "INSERT INTO tb_kontak VALUES (null, '$alamat','$email','$no_hp','$ig','$yt','$tiktok','$maps')");
header("Location:dashboard_admin.php?p=data_kontak&notif=sukses");
// var_dump($alamat);
// die();
}
 ?>