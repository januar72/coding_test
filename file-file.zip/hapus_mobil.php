<?php 
include 'koneksi.php';
$id =$_GET['id'];

$hapus=mysqli_query($conn, "DELETE FROM tb_mobil WHERE id_mobil='$id'");
header("Location:dashboard_admin.php?p=data_mobil");

 ?>