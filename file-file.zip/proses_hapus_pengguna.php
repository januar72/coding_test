<?php 
include 'koneksi.php';

$id =$_GET['id'];

$hapus =mysqli_query($conn, "DELETE FROM tb_user WHERE id_user='$id'");
header("Location:dashboard_admin.php?p=index_admin&notif=sukses_hapus");


 ?>