<?php 
$host ="localhost";
$user ="root";
$pass ="";
$db ="db_medika";

$conn =mysqli_connect($host, $user, $pass, $db);

 ?>