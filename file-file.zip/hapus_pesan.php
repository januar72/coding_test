<?php 
include 'koneksi.php';
$id =$_GET['id'];

$hapus =mysqli_query($conn,  "DELETE FROM tb_pesan WHERE id_pesan='$id'");
header("location:dashboard_admin.php?p=detail_pesan&notif=sukses");

 ?>